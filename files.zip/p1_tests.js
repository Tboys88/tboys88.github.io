/* Tes P1: jalankan  node p1_tests.js <path trdi.html hasil patch>   — deterministik, tanpa jaringan */
const {load}=require("./env.js"),assert=require("assert");
const FILE=process.argv[2]||"/mnt/user-data/outputs/trdi_v10_p1.html";
const E=load(FILE,{vals:{"#bal":"1000","#risk":"1","#lev":"20","#spr":"0","#dl":"3"}});
let pass=0,fail=0;const T=(n,f)=>{try{f();pass++;console.log("  ✓",n)}catch(e){fail++;console.log("  ✗",n,"\n     ",e.message.split("\n")[0])}};
const G=n=>E.get(n),run=c=>E.run(c),near=(a,b,t=1e-9,m)=>assert.ok(Math.abs(a-b)<=t,(m||"")+` ${a} ≉ ${b}`);
console.log("load errors:",E.errors.length?E.errors:"tidak ada");
const k=(t,o,h,l,c)=>({t,o,h,l,c,v:100}),H=36e5;
const sim=(d,o)=>run(`simExit(${JSON.stringify(d)},0,${JSON.stringify(o)})`);
const base={dir:1,e:100,sd:2,sl:98,tp:104,max:50,part:1,trail:0,hs:0};

console.log("\n[simExit — konservatif]");
T("SL-first: SL & TP di candle sama → rugi -1R",()=>{const r=sim([k(0,100,105,97,101)],{...base,part:0});near(r.R,-1);assert.equal(r.why,"SL")});
T("short simetris: SL & TP satu candle → -1R",()=>{const r=sim([k(0,100,103,95,99)],{...base,dir:-1,sl:102,tp:96,part:0});near(r.R,-1)});
T("gap melewati SL: fill di OPEN, rugi > 1R",()=>{const r=sim([k(0,95,96,94,95)],{...base,part:0});near(r.R,-2.5);assert.equal(r.why,"GAP");near(r.gap,1.5)});
T("TP butuh tembus setengah spread (hs)",()=>{const d=[k(0,100,104.1,100.5,103),k(1,103,104.3,102,104)];const r=sim(d,{...base,part:0,hs:0.2});assert.equal(r.j,1);near(r.R,2);const r0=sim(d,{...base,part:0,hs:0});assert.equal(r0.j,0)});
T("partial +1R lalu TP di candle berikut → +1,5R",()=>{const r=sim([k(0,100,102.5,100.5,102),k(1,102,105,101,104)],base);near(r.R,1.5);assert.equal(r.why,"TP")});
T("partial & sentuh impas di candle sama → dianggap kena impas (+0,5R, amb=1)",()=>{const r=sim([k(0,100,102.2,99.9,101),k(1,101,105,100.5,104)],base);near(r.R,0.5);assert.equal(r.amb,1);assert.equal(r.why,"BE*")});
T("TP & sentuh impas di candle sama (partial aktif) → +0,5R, bukan +1,5R",()=>{const r=sim([k(0,100,105,99.5,104)],base);near(r.R,0.5);assert.equal(r.amb,1)});
T("setelah partial, BE kena di candle berikut → +0,5R",()=>{const r=sim([k(0,100,102.5,100.5,102),k(1,102,102.5,99.8,100.2)],base);near(r.R,0.5);assert.equal(r.why,"BE")});
T("invalidation exit di close (low masih di atas SL)",()=>{const r=sim([k(0,100,100.5,98.5,98.9)],{...base,part:0,inv:99});near(r.R,-0.55);assert.equal(r.why,"INV")});
T("tanpa kejadian → MTM di akhir, dijepit [-1,2]",()=>{const r=sim([k(0,100,100.6,99.4,100.4),k(1,100.4,100.9,100,100.6)],{...base,part:0,max:2});assert.equal(r.why,"MTM");near(r.R,0.3)});
T("deterministik: dua kali panggil → hasil identik",()=>{const d=[k(0,100,102.5,100.5,102),k(1,102,105,101,104)];assert.deepStrictEqual(sim(d,base),sim(d,base))});

console.log("\n[costR / biaya dinamis]");
const X=(sym,px,t,vm)=>JSON.parse(JSON.stringify(run(`cstDyn("${sym}",${px},${t},${vm})`)));
const WED=Date.UTC(2026,10,11); /* Rabu 2026-11-11 */
T("costR statis (tanpa konteks) = (spread+slip(1+wS)+komisi)/sd",()=>{const c=JSON.parse(JSON.stringify(run(`cst("EURUSD",1.1)`)));near(run(`costR("EURUSD",1.1,0.002,{wS:1})`),(c.sp+c.sl*2+c.cm*1.1)/0.002,1e-12)});
T("spread dinamis: London 10:00 UTC (di luar jam rilis) = statis",()=>{const a=X("EURUSD",1.1,WED+10*H,1),c=JSON.parse(JSON.stringify(run(`cst("EURUSD",1.1)`)));near(a.sp,c.sp,1e-12)});
T("spread ×3 saat rollover 22:00 UTC, ×1,5 sesi Asia",()=>{const c=JSON.parse(JSON.stringify(run(`cst("EURUSD",1.1)`)));near(X("EURUSD",1.1,WED+22*H,1).sp,3*c.sp,1e-12);near(X("EURUSD",1.1,WED+3*H,1).sp,1.5*c.sp,1e-12)});
T("jam rilis berita (12–15 UTC) melebarkan spread ×2",()=>{const c=JSON.parse(JSON.stringify(run(`cst("EURUSD",1.1)`)));near(X("EURUSD",1.1,WED+13*H,1).sp,2*c.sp,1e-12)});
T("volatilitas dijepit ke 3: spread ×√3, slippage ×3",()=>{const c=JSON.parse(JSON.stringify(run(`cst("EURUSD",1.1)`))),a=X("EURUSD",1.1,WED+10*H,9);near(a.sp,c.sp*Math.sqrt(3),1e-12);near(a.sl,c.sl*3,1e-12)});
T("rollover: forex lewat 22:00 UTC sekali; crypto 24 jam = 3 funding",()=>{assert.equal(run(`rolls("forex",${WED+21*H},${WED+23*H})`),1);assert.equal(run(`rolls("crypto",${WED+1},${WED+24*H})`),3);assert.equal(run(`rolls("forex",${WED+1*H},${WED+5*H})`),0)});
T("swap/funding menambah biaya R sebesar rolls×swp%×e/sd",()=>{const a=run(`costR("BTCUSDT",50000,500,{wS:0,t:${WED+1},j:0},{t:${WED+1}})`),b=run(`costR("BTCUSDT",50000,500,{wS:0,t:${WED+24*H},j:0},{t:${WED+1}})`);near(b-a,3*run('V.cost.crypto.swp')/100*50000/500,1e-9)});
T("gap entry adverse & requote menambah biaya",()=>{const a=run(`costR("EURUSD",1.1,0.002,{wS:0},{t:${WED+10*H},vm:1})`),b=run(`costR("EURUSD",1.1,0.002,{wS:0},{t:${WED+10*H},vm:1,adv:0.2,rq:1})`),sp=X("EURUSD",1.1,WED+10*H,1).sp;near(b-a,0.2+0.5*sp/0.002,1e-9)});

console.log("\n[execModel — reject/requote/partial]");
T("deterministik untuk argumen sama",()=>assert.deepStrictEqual(run(`execModel("BTCUSDT","a",12345,1,false)`),run(`execModel("BTCUSDT","a",12345,1,false)`)));
T("tingkat tolak ≈ rejP (2%) pada 20.000 sampel; dobel saat volatil+berita",()=>{const r=run(`(()=>{let a=0,b=0;for(let i=0;i<20000;i++){if(execModel("EURUSD","a",i*60000,1,false).rej)a++;if(execModel("EURUSD","a",i*60000,2,true).rej)b++}return[a/20000,b/20000]})()`);assert.ok(r[0]>0.015&&r[0]<0.025,"base "+r[0]);assert.ok(r[1]>0.06&&r[1]<0.10,"stres "+r[1])});

console.log("\n[statistik: normal, DSR, bootstrap]");
T("normInv/normCdf akurat",()=>{near(run("normInv(0.975)"),1.959964,1e-4);near(run("normInv(0.5)"),0,1e-9);near(run("normInv(0.999)"),3.090232,1e-3);near(run("normCdf(1.96)"),0.975,1e-4);near(run("normCdf(normInv(0.3))"),0.3,1e-6)});
const gen=`const rg=xRng(42);const gauss=()=>Math.sqrt(-2*Math.log(rg()+1e-12))*Math.cos(2*Math.PI*rg());`;
T("DSR: edge kuat (n=300, μ=.5R) tinggi; tanpa edge (μ=0) rendah",()=>{const r=run(`(()=>{${gen}const a=[],b=[];for(let i=0;i<300;i++){a.push(0.5+gauss());b.push(gauss())}return[dsr(a,72).p,dsr(b,72).p]})()`);assert.ok(r[0]>0.9,"edge "+r[0]);assert.ok(r[1]<0.3,"null "+r[1])});
T("bootstrap: P(exp≤0) kecil untuk edge, besar untuk null",()=>{const r=run(`(()=>{${gen}const a=[],b=[];for(let i=0;i<200;i++){a.push(0.5+gauss());b.push(gauss())}return[mcBoot(a).pNeg,mcBoot(b).pNeg]})()`);assert.ok(r[0]<0.01);assert.ok(r[1]>0.1)});

console.log("\n[walkForward sejati]");
const mkRec=(n,fn)=>`(()=>{${gen}const o=[];for(let i=0;i<${n};i++){const t=Date.UTC(2025,0,1)+i*864e5/ (${n}/400),f=(${fn});o.push({t,r:f.m+gauss(),nc:f.nc||5,rm:f.rm||3,adx:f.adx==null?25:f.adx})}return o})()`;
T("edge stabil → ≥5 jendela valid, OOS positif, ok",()=>{const w=run(`walkForward(${mkRec(500,"({m:0.35})")})`);assert.equal(w.valid,5);assert.ok(w.oos.exp>0.15);assert.equal(w.ok,true)});
T("tanpa edge → ok=false",()=>{const w=run(`walkForward(${mkRec(500,"({m:-0.05})")})`);assert.equal(w.ok,false)});
T("kurang trade → ditolak dengan alasan",()=>{const w=run(`walkForward(${mkRec(30,"({m:0.5})")})`);assert.equal(w.ok,false);assert.ok(/butuh/.test(w.txt))});
T("TANPA kebocoran: parameter bagus di latih, rezim berbalik di uji → OOS tidak ikut bagus",()=>{
 const w=run(`walkForward(${mkRec(800,"({m:0.0,adx:(i%2?30:10),nc:5,rm:3,_x:0})").replace("r:f.m+gauss()","r:(i%2?(t<Date.UTC(2025,0,1)+864e5*220?0.9:-0.9):0)+gauss()")})`);
 assert.ok(w.oos.exp<0.3,"OOS "+w.oos.exp);assert.equal(w.ok,false)});
T("jendela uji selalu SETELAH jendela latih (tidak tumpang tindih)",()=>{const w=run(`walkForward(${mkRec(500,"({m:0.3})")})`);assert.equal(w.w.length,5);w.w.forEach(x=>assert.ok(x.te&&x.tr))});
T("sensitivitas: edge menyebar di semua grid → ok; edge hanya di satu sudut → tidak ok",()=>{const a=run(`sensGrid(${mkRec(500,"({m:0.3})")})`),b=run(`sensGrid(${mkRec(500,"({m:-0.3})").replace("r:f.m+gauss()","r:(i%7===0?2.5:-0.35)+gauss()*0.2")})`);assert.equal(a.ok,true);assert.ok(a.k>=6)});

console.log("\n[kuatState — ambang 100 trade, CI, OOS]");
const summOf=(n,m)=>`(()=>{const rec=${mkRec(n,`({m:${m}})`)};return summ(rec.map(x=>x.r),rec.map(x=>x.t),400,3000,rec)})()`;
T("n=99 → DATA KURANG",()=>{const s=run(`kuatState(${summOf(99,0.5)})`);assert.equal(s.s,"DATA KURANG")});
T("edge kuat n=500 → KUAT",()=>{const s=run(`kuatState(${summOf(500,0.4)})`);assert.equal(s.ok,true,s.why)});
T("n=120 edge tipis (0,2R): CI95 bawah ≤ 0 → BELUM LOLOS dengan alasan CI",()=>{const s=run(`kuatState(${summOf(120,0.2)})`);assert.equal(s.ok,false);assert.ok(/CI95|walk-forward|sensitivitas|expectancy/.test(s.why),s.why)});
T("tanpa edge n=300 → BELUM LOLOS",()=>assert.equal(run(`kuatState(${summOf(300,0)})`).ok,false));
T("peringatan sampel kecil muncul bila n<200 namun lolos",()=>{const s=run(`kuatState(${summOf(150,0.6)})`);if(s.ok)assert.ok(s.warn.some(x=>/sampel/.test(x)))});

console.log("\n[fitLot / splitHalf]");
T("forex: 123456 unit → 1,23 lot dibulatkan KE BAWAH",()=>{const f=run(`fitLot("EURUSD",123456)`);near(f.lots,1.23);assert.equal(f.qty,123000);assert.equal(f.forced,false)});
T("di bawah min lot dipaksa ke min (forced=true → risiko aktual > target)",()=>{const f=run(`fitLot("EURUSD",500)`);near(f.lots,0.01);assert.equal(f.forced,true)});
T("input tak valid → 0",()=>{assert.equal(run(`fitLot("EURUSD",0).qty`),0);assert.equal(run(`fitLot("EURUSD",NaN).qty`),0)});
T("splitHalf: 0,01 lot tidak bisa dipecah → 0; 3 lot → 1,5; 0,03 → 0,01",()=>{assert.equal(run(`splitHalf("EURUSD",1000)`),0);assert.equal(run(`splitHalf("EURUSD",300000)`),150000);assert.equal(run(`splitHalf("EURUSD",3000)`),1000)});
T("crypto step 0,0001",()=>{near(run(`fitLot("BTCUSDT",0.01234567)`).lots,0.0123,1e-12)});

console.log("\n[buildTradePlan]");
const plan=(dir,entry,lv,sp,atr=1)=>JSON.parse(JSON.stringify(run(`buildTradePlan(${dir},${entry},{atr:${atr},cd:[],sym:"EURUSD",noExpo:1,tfk:"5m",lv:${JSON.stringify(lv)}},${sp})`)));
T("long: SL di support −0,25ATR−spread; TP1=1R, TP2=2R",()=>{const p=plan(1,100,{sup:98.5,res:110},0.05);assert.equal(p.ok,true);near(p.sd,1.8,1e-9);near(p.sl,98.2,1e-9);near(p.tp2,103.6,1e-9);near(p.tp1,101.8,1e-9)});
T("spread > 10% jarak SL → diblokir",()=>{const p=plan(1,100,{sup:98.5,res:110},0.2);assert.equal(p.ok,false);assert.ok(/spread/.test(p.reason))});
T("SL > 2,5 ATR → diblokir",()=>{const p=plan(1,100,{sup:95,res:120},0.01);assert.equal(p.ok,false);assert.ok(/SL terlalu jauh/.test(p.reason))});
T("batas room = RULES.minRoom (2,2R): 2,2 lolos, 2,19 ditolak",()=>{const mr=run("RULES.minRoom");near(mr,2.2);assert.equal(plan(1,100,{sup:98.5,res:100+2.2*1.8+1e-6},0.05).ok,true);assert.equal(plan(1,100,{sup:98.5,res:100+2.19*1.8},0.05).ok,false)});
T("short simetris",()=>{const p=plan(-1,100,{sup:80,res:101.5},0.05);assert.equal(p.ok,true);near(p.sd,1.8,1e-9);near(p.tp2,96.4,1e-9)});
T("tanpa arah/ATR → tidak ok",()=>assert.equal(plan(0,100,{sup:98,res:110},0).ok,false));

console.log("\n[aturan harian: satu definisi]");
T("RULES tidak lagi memuat 'pb' mati; day=3, pair=1",()=>{const r=run("RULES");assert.equal(r.pb,undefined);assert.equal(r.day,3);assert.equal(r.pair,1)});
T("TF.min 4h=240, 1d=1440 (sebelumnya 60)",()=>{assert.equal(run("TF['4h'].min"),240);assert.equal(run("TF['1d'].min"),1440);assert.equal(run("EXP['4h']"),240);assert.equal(run("D2T[1440]"),"1d")});
T("dayEntries tidak menghitung latihan harian/prac",()=>{run(`S.hist=[{t:new Date().toISOString(),pnl:1,daily:1},{t:new Date().toISOString(),pnl:1,prac:1}];D=null;S.man.pos=[]`);assert.equal(run("dayEntries()"),0);run(`S.hist=[{t:new Date().toISOString(),pnl:1}]`);assert.equal(run("dayEntries()"),1);run("S.hist=[]")});

console.log("\n[canTrade — pintu tunggal]");
const ct=(ctx="{}")=>run(`canTrade(${ctx})`);
T("default tanpa setup tervalidasi → TIDAK boleh",()=>{const r=ct("{sym:'BTCUSDT'}");assert.equal(r.ok,false);assert.ok(r.alasan.some(x=>/Tidak ada setup/.test(x)))});
T("kill switch → ditolak",()=>{run("S.halt=true");const r=ct("{sym:'BTCUSDT'}");run("S.halt=false");assert.ok(r.alasan.some(x=>/KILL SWITCH/.test(x)))});
T("DS.fail>0 → ditolak karena data",()=>{run("DS.fail=1");const r=ct("{sym:'BTCUSDT'}");run("DS.fail=0");assert.ok(r.alasan.some(x=>/DATA/.test(x)))});
T("kalender basi → ditolak (bebas-berita tak terjamin)",()=>{run("V.calT=0");const r=ct("{sym:'BTCUSDT'}");assert.ok(r.alasan.some(x=>/BERITA/.test(x)))});
T("harga/candle basi → data tidak ok",()=>{run("LK=[{t:Date.now()-10*36e5,o:1,h:1,l:1,c:1,v:1}];P=1;PT=Date.now()");const r=ct("{sym:'BTCUSDT'}");assert.ok(r.alasan.some(x=>/basi|DATA/.test(x)))});
T("sinyal duplikat dalam jendela → ditolak",()=>{const k0=ct("{sym:'BTCUSDT',dir:1}").key;run(`markSig(${JSON.stringify(k0)})`);const r=ct("{sym:'BTCUSDT',dir:1}");assert.ok(r.alasan.some(x=>/DUPLIKAT/.test(x)))});
T("batas 3 trade/hari → ditolak",()=>{run(`S.hist=[1,2,3].map(()=>({t:new Date().toISOString(),pnl:1}))`);const r=ct("{sym:'BTCUSDT'}");run("S.hist=[]");assert.ok(r.alasan.some(x=>/batas 3 trade/.test(x)))});
T("margin tidak cukup → ditolak",()=>{run("D={on:true,bal:10,bal0:10,pos:[],curve:[]}");const r=ct("{sym:'BTCUSDT',px:50000,qty:1,src:'auto'}");run("D=null");assert.ok(r.alasan.some(x=>/MARGIN/.test(x)))});
T("alasan tidak duplikat; ok=false selalu punya ≥1 alasan",()=>{const r=ct("{sym:'BTCUSDT'}");assert.equal(r.alasan.length,new Set(r.alasan).size);assert.ok(r.ok||r.alasan.length>0)});

console.log("\n[kill switch & reconcile]");
T("killAll idempoten: panggilan kedua tidak error & tetap halt",()=>{run("S.halt=false;D=null;S.man.pos=[];S.man.pend=[]");run("killAll('tes')");run("killAll('tes')");assert.equal(run("S.halt"),true);assert.equal(run("S.autoOff"),true);run("S.halt=false")});
T("reconcile tanpa broker: ok=null & jujur menyatakan tidak bisa mencocokkan",()=>{const r=run("reconcile()");assert.equal(r.ok,null);assert.ok(/Tidak ada broker/.test(r.note))});

console.log("\n[integrasi bt() pada candle sintetis — determinisme & invarian]");
const btCode=`(async()=>{const rg=xRng(7);let p=100;const d=[];for(let i=0;i<900;i++){const dr=Math.sin(i/60)*0.08,o=p,c=p+dr+(rg()-0.5)*0.9,h=Math.max(o,c)+rg()*0.4,l=Math.min(o,c)-rg()*0.4;d.push({t:Date.UTC(2026,0,5)+i*36e5,o,h,l,c,v:100+rg()*50});p=c}delete BTC["BTCUSDT|1h"];const a=await bt(d,"BTCUSDT|1h",[]);delete BTC["BTCUSDT|1h"];const b=await bt(d,"BTCUSDT|1h",[]);return{a:JSON.stringify(a),b:JSON.stringify(b),o:a}})()`;
let btRes=null;
(async()=>{try{btRes=await E.run(btCode)}catch(e){fail++;console.log("  ✗ bt() melempar error:",e.message)}
 if(btRes){
 T("bt() deterministik: dua run identik",()=>assert.equal(btRes.a,btRes.b));
 T("invarian: n == fill; fill ≤ sig; rate∈[0,1]; amb,gap ≥ 0",()=>{for(const p of ["a","b","c","d"]){const o=btRes.o[p];assert.equal(o.n,o.fx.fill);assert.ok(o.fx.fill<=o.fx.sig);assert.ok(o.fx.rate>=0&&o.fx.rate<=1);assert.ok(o.fx.amb>=0&&o.fx.gapN>=0);assert.ok(o.wf&&o.sens)}});
 T("tidak ada klaim KUAT pada data sintetis pendek",()=>{for(const p of ["a","b","c","d"])assert.notEqual(run(`kuatState(BTC["BTCUSDT|1h"].o.${p}).s`),"KUAT")});
 const tot=["a","b","c","d"].reduce((s,p)=>s+btRes.o[p].n,0);console.log("    info: total trade sintetis =",tot,"| fx(a) =",JSON.stringify(btRes.o.a.fx));}
 console.log(`\nHASIL: ${pass} lulus, ${fail} gagal`);process.exit(fail?1:0)})();
