# AI Trading Agent v10 — Patch P1 (validasi konservatif)

Berkas
- trdi_v10_p1.html        file hasil patch (siap dipakai; satu file mandiri)
- p1_patch/blockA..D      blok kode per fungsi (untuk ditempel manual)
- p1_patch/build.js       skrip yang menerapkan patch ke trdi.html asli (verifikasi anchor; gagal jika asli berbeda)
- p1_patch/trdi_p1.diff   diff terhadap file asli
- p1_tests/               tes otomatis (Node ≥18, tanpa jaringan)

Menjalankan tes
  node p1_tests/p1_tests.js      <path trdi_v10_p1.html>    # 63 tes
  node p1_tests/p1_live_tests.js <path trdi_v10_p1.html>    # 10 tes
  node p1_tests/compare.js                                  # asli vs patch pada candle sintetis yang sama
(ubah path SRC/OUT di p1_patch/build.js bila folder berbeda)

Peta penggantian (baris pada file asli)
  797-811  simExit + costR            -> blockA_exec.js  (+ model eksekusi: sessMult, cstDyn, rolls, execModel)
  735-750  bt()                       -> blockB_bt.js
  635-648  monteCarlo..btFull         -> blockC_stats.js (KRIT, walkForward, DSR, bootstrap, sensitivitas, kuatState)
  1127-1129 fillCost                  -> spread/slippage dinamis + swap (inline di build.js)
  sebelum closePos                    -> blockD_live.js  (slipRec, slipStat, edgeDecay, renderLive)
  + edit kecil: hzSettle, pickSetup (total ≥200), RULES.pb, dayEntries, TF.min 4h/1d, teks ambang, panel UI #p1live

Semua angka di V.ex (reject/requote/partial/penalti TP/pengali berita) dan V.cost[k].swp adalah ASUMSI,
bukan hasil kalibrasi broker. Ukur selisihnya lewat panel "Live vs backtest".
